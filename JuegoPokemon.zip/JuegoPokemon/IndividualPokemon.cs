﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoPokemon
{
    class IndividualPokemon
    {
        public static SpeciesPokemon[] initialPokemons()
        {
            SpeciesPokemon[] initPokemon = new SpeciesPokemon[3];
            initPokemon[0] = new SpeciesPokemon("BULBASAUR", "GRASS", 5, 45, 45, 49, 49, 45);
            initPokemon[1] = new SpeciesPokemon("CHARMANDER", "FIRE", 5, 39, 39, 52, 43, 65);
            initPokemon[2] = new SpeciesPokemon("SQUIRTLE", "WATER", 5, 44, 44, 48, 65, 43);
            return initPokemon;
        }

        public static SpeciesPokemon[] rivalPokemons()
        {
            SpeciesPokemon[] rivalPokemon = new SpeciesPokemon[3];
            rivalPokemon[0] = new SpeciesPokemon("RATTATA", "NORMAL", 5, 30, 30, 56, 35, 72);
            rivalPokemon[1] = new SpeciesPokemon("KAKUNA", "BUG", 5, 45, 45, 25, 50, 35);
            rivalPokemon[2] = new SpeciesPokemon("SPEAROW", "FLYING", 5, 40, 40, 60, 30, 70);
            return rivalPokemon;
        }
    }
}
