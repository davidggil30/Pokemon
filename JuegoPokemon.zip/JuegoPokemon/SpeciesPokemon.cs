﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoPokemon
{
    class SpeciesPokemon
    {
        // Atributos
        string name;
        string type;
        char gender;
        int lvl;
        int maxHP;
        int currentHP;
        int atack;
        int defense;
        int speed;
        int rc; // ratio de captura
        DateTime date;

        Random rand = new Random();

        // Constructores
        public SpeciesPokemon(string name, string type, int lvl, int maxHP, int currentHP, int atack, int defense, int speed)
        {
            this.name = name;
            this.type = type;
            this.maxHP = maxHP;
            this.currentHP = currentHP;
            this.atack = atack;
            this.defense = defense;
            this.speed = speed;
            this.lvl = lvl;
            gender = GenerateGender();
            rc = generateRc();
        }
        

        // Getter y Setters
        public string getName()
        {
            return name;
        }
        public void setName(string name)
        {
            this.name = name;
        }
        public string getType()
        {
            return type;
        }
        public void setType(string type)
        {
            this.type = type;
        }
        public int getMaxHP()
        {
            return maxHP;
        }
        public void setMaxHP(int maxHP)
        {
            this.maxHP = maxHP;
        }
        public int getCurrentHP()
        {
            return currentHP;
        }
        public void setCurrentHP(int currentHP)
        {
            this.currentHP = currentHP;
        }
        public int getSpeed()
        {
            return speed;
        }
        public void setSpeed(int speed)
        {
            this.speed = speed;
        }
        public int getLevel()
        {
            return lvl;
        }
        public void setLevel(int lvl)
        {
            this.lvl = lvl;
        }
        public int getAtack()
        {
            return atack;
        }
        public void setAtack(int atack)
        {
            this.atack = atack;
        }
        public int getDefense()
        {
            return defense;
        }
        public void setDefense(int defense)
        {
            this.defense = defense;
        }
        public char getGender()
        {
            return gender;
        }
        public char GenerateGender()
        {
            Random r = new Random();
            int num = r.Next(0,2);
            if(num == 0)
            {
                return 'M';
            }
            else
            {
                return 'F';
            }
        }
        public int getRc()
        {
            return rc;
        }
        public void setRc(int rc)
        {
            this.rc = rc;
        }
        public int generateRc()
        {
            int rc = rand.Next(0, 256);
            return rc;
        }
        public void setDate(DateTime date)
        {
            this.date = date;
        }
        public DateTime getDate()
        {
            return date;
        }
    }
}
