﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.Remoting;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace JuegoPokemon
{
    class Game
    {
        SpeciesPokemon[] initialPokemon = IndividualPokemon.initialPokemons();
        SpeciesPokemon[] myPokemons = new SpeciesPokemon[6];
        SpeciesPokemon[] rivalPokemon = IndividualPokemon.rivalPokemons();
        SpeciesPokemon[] myRivalPokemon = new SpeciesPokemon[1];
        //Menú
        public void Menu()
        {
            IO.slowType("¡Hola! \n¡Éste es el mundo de POKéMON! \n¡Me llamo OAK! ¡Pero la gente me llama PROFESOR POKéMON! " +
                "¡Éste mundo está habitado por unas criaturas llamadas POKéMON!" + "\nPara algunos los POKéMON son sólo mascotas. Pero otros los usan para pelear. " +
                "\nBueno, cuéntame algo de ti..." + "¿Cómo te llamas?   ", 0);
            string name = nameMister();
            IO.slowType("\nBienvenido " + name + ", vamos a comenzar.", 0);
            IO.slowType("\n¡Aquí hay tres POKéMON! ¡Están dentro de las POKé BALLS! Te daré uno. ¿Cuál quieres?", 0);
            IO.slowType("\n\t 1.- " + initialPokemon[0].getName() + " \n\t 2.- " + initialPokemon[1].getName() + " \n\t 3.- " + initialPokemon[2].getName() + "\n", 0);
            Console.WriteLine("\t Has elegido a " + chooseInitPokemon());
            Console.WriteLine();
            mainMenu();
        }

        // Elegir nombre del entrenador
        public string nameMister()
        {
            string name = IO.text();
            return name;
        }

        // Elegir 1 POKéMON inicial de los 3 posibles
        public string chooseInitPokemon()
        {
            IO.slowType("   Introduce una opción: ", 0);
            int option = IO.intToString();
            for (int i = 0; i < initialPokemon.Length; ++i)
            {
                do
                {
                    switch (option)
                    {
                        case 1:
                            myPokemons[0] = initialPokemon[0];
                            return initialPokemon[0].getName();
                        case 2:
                            myPokemons[0] = initialPokemon[1];
                            return initialPokemon[1].getName();
                        case 3:
                            myPokemons[0] = initialPokemon[2];
                            return initialPokemon[2].getName();
                    }
                } while (option > 0 && option < 4);
            }
            IO.slowType("   Introduce una opción correcta: ", 0);
            return chooseInitPokemon();
        }

        // Menú principal
        public void mainMenu()
        {
            IO.slowType("\n ¿Qúe desea hacer? ", 0);
            IO.slowType("\n\t 1.- Ver los datos de los POKéMON del equipo. \n\t 2.- Combatir. \n\t 3.- Centro POKéMON \n\t 4.- Cerrar el juego. \n", 0);
            int option = 0;
            do
            {
                Console.Write("   Elige una opción: ");
                option = IO.intToString();
                switch (option)
                {
                    case 1:
                        showPokemon();
                        mainMenu();
                        break;
                    case 2:
                        Console.WriteLine();
                        IO.slowType("¡Te has encontrado con un " + chooseRivalPokemon() + " salvaje! ¡Ten cuidado, será muy difícil de vencer! ", 0);
                        Combate();
                        break;
                    case 3:
                        IO.slowType("Recuperando la vida de todos tus POKéMON...", 0);
                        IO.slowType(".......................................", 0);
                        centroPokemon();
                        mainMenu();
                        break;
                    case 4:
                        Exit();
                        break;
                }
                Console.WriteLine();
            } while (option > 0 && option < 5);
            IO.slowType("Introduce una opción correcta: ", 0);
            mainMenu();
        }

        // Ver mi equipo
        public void showPokemon()
        {
            Console.WriteLine("¡Muy bien! Veamos cúales son tus POKéMON: ");
            //SpeciesPokemon[] initialPokemon = IndividualPokemon.PokemonIniciales();
            for (int i = 0; i < myPokemons.Length; i+=1)
            {
                if (myPokemons[i] != null)
                {
                    IO.slowType("\n Nombre: " + myPokemons[i].getName() +
                    "\n Tipo: " + myPokemons[i].getType() +
                    "\n Nivel: " + myPokemons[i].getLevel() +
                    "\n Género: " + myPokemons[i].getGender() + 
                    "\n Vida máxima: " + myPokemons[i].getMaxHP() +
                    "\n Vida actual: " + myPokemons[i].getCurrentHP() +
                    "\n Ataque: " + myPokemons[i].getAtack() +
                    "\n Defensa: " + myPokemons[i].getDefense() +
                    "\n Velocidad: " + myPokemons[i].getSpeed() +
                    "\n " + myPokemons[i].getDate() +
                    "\n ", 0);
                }
            }
        }

        // Centro POKéMON
        public void centroPokemon()
        {
            for(int i = 0; i < myPokemons.Length; ++i)
            {
                if(myPokemons[i] != null)
                {
                    myPokemons[i].setCurrentHP(myPokemons[i].getMaxHP());
                }
            }
        }

        // Salir del programa
        public void Exit()
        {
            IO.slowType("¿Desea salir del programa? \n 1.- Si \n 2.- No", 0);
            int option = IO.intToString();
            switch (option)
            {
                case 1:
                    Environment.Exit(0);
                    break;
                case 2:
                    mainMenu();
                    break;
            }
        }

        // Combate
        public void Combate()
        {
            int option = 0;
            //IO.slowType("¿Con qué POKéMON quieres atacar?", 0);
            //option = IO.intToString();
            //for (int i = 0; i < myPokemons.Length; ++i)
            //{
            //    IO.slowType("\n\t " + (i+1) + myPokemons[i].getName(), 0);
            //    SpeciesPokemon miPokemon = myPokemons[option-1];
            //}
            SpeciesPokemon miPokemon = choosePokemonAttack();
            IO.slowType("\n\t 1.- Atacar \n\t 2.- Cambiar de POKéMON \n\t 3.- Capturar POKéMON \n\t 4.- Escapar", 0);
            SpeciesPokemon rivalPokemon = myRivalPokemon[0];
            if(miPokemon.getCurrentHP() <= 0)
            {
                IO.slowType("\n Tu POKéMON " + miPokemon.getName() + " tiene " + miPokemon.getCurrentHP() + " vida.\n Te llevaremos al centro POKéMON. ", 0);
                centroPokemon();
            }
            do
            {
                IO.slowType("\nElige una opción: ", 0);
                option = IO.intToString();
                switch (option)
                {
                    case 1:
                        attack(miPokemon, rivalPokemon);
                        break;
                    case 2:
                        Console.WriteLine("¡Perfecto! Has elegido cambiar de POKéMON");
                        miPokemon = changePokemon(miPokemon);
                        break;
                    case 3:
                        IO.slowType("\n Capturando POKéMON...", 0);
                        IO.slowType("\n .............................................", 0);
                        capture(rivalPokemon);
                        break;
                    case 4:
                        Console.WriteLine("Escapar");
                        getAway(miPokemon, rivalPokemon);
                        break;
                    case 5:
                        mainMenu();
                        break;
                }
            } while (option > 0 && option < 5);
            IO.slowType("Introduce una opción correcta: ", 0);
            Combate();
        }

        // Elegir miPokemon para atacar
        public SpeciesPokemon choosePokemonAttack()
        {
            int option = 0;
            IO.slowType("\n\n ¿Con qué POKéMON quieres atacar?", 0);
            for (int i = 0; i < myPokemons.Length; ++i)
            {
                if (myPokemons[i] != null)
                {
                    IO.slowType("\n\t " + (i + 1) + ".- " + myPokemons[i].getName(), 0);
                    IO.slowType("\n Introduce una opción: ", 0);
                    option = IO.intToString();
                    SpeciesPokemon miPokemon = myPokemons[option - 1];
                    return miPokemon;
                }
            }
            return choosePokemonAttack();
        }

        //Elegir POKéMON rival
        public string chooseRivalPokemon()
        {
            Random random = new Random();
            int option = random.Next(1, 4);
            for (int i = 0; i < rivalPokemon.Length; ++i)
            {
                do
                {
                    switch (option)
                    {
                        case 1:
                            myRivalPokemon[0] = rivalPokemon[0];
                            myRivalPokemon[0].setCurrentHP(myRivalPokemon[0].getMaxHP());
                            return rivalPokemon[0].getName();
                            break;
                        case 2:
                            myRivalPokemon[0] = rivalPokemon[1];
                            myRivalPokemon[0].setCurrentHP(myRivalPokemon[0].getMaxHP());
                            return rivalPokemon[1].getName();
                            break;
                        case 3:
                            myRivalPokemon[0] = rivalPokemon[2];
                            myRivalPokemon[0].setCurrentHP(myRivalPokemon[0].getMaxHP());
                            return rivalPokemon[2].getName();
                            break;
                    }
                } while (option > 0 && option < 4);
            }
            IO.slowType("Introduce una opción correcta: ", 0);
            return chooseRivalPokemon();
        }

        // Atacar
        public void attack(SpeciesPokemon miPokemon, SpeciesPokemon pokemonRival)
        {
            if (miPokemon.getSpeed() > pokemonRival.getSpeed())
            {
                pokemonRival.setCurrentHP(pokemonRival.getCurrentHP() - damage(miPokemon, pokemonRival));
                miPokemon.setCurrentHP(miPokemon.getCurrentHP() - damage(pokemonRival, miPokemon));
                if (miPokemon.getCurrentHP() > 0 && pokemonRival.getCurrentHP() > 0)
                {
                    IO.slowType("\n Tu pokemon " + miPokemon.getName() + " tiene " + miPokemon.getCurrentHP() + " de vida actual.", 0);
                    IO.slowType("\n Tu pokemon rival " + pokemonRival.getName() + " tiene " + pokemonRival.getCurrentHP() + " de vida actual.", 0);
                }
                weakened(miPokemon, pokemonRival);
            }
            else
            {
                miPokemon.setCurrentHP(miPokemon.getCurrentHP() - damage(pokemonRival, miPokemon));
                pokemonRival.setCurrentHP(pokemonRival.getCurrentHP() - damage(miPokemon, pokemonRival));
                if (miPokemon.getCurrentHP() > 0 && pokemonRival.getCurrentHP() > 0)
                {
                    IO.slowType("\n Tu pokemon " + miPokemon.getName() + " tiene " + miPokemon.getCurrentHP() + " de vida actual.", 0);
                    IO.slowType("\n Tu pokemon rival " + pokemonRival.getName() + " tiene " + pokemonRival.getCurrentHP() + " de vida actual.", 0);
                } 
                weakened(miPokemon, pokemonRival);
            }
        }
        
        // Cambiar POKéMON
        public SpeciesPokemon changePokemon(SpeciesPokemon pokemonFighter)
        {
            for (int i = 0; i < myPokemons.Length; ++i)
            {
                if (myPokemons[i] != null && myPokemons[i] != pokemonFighter)
                {
                    IO.slowType("\n\t " + (i+1) + ".- "+ myPokemons[i].getName(), 0);
                }
            }

            IO.slowType("\n ¿Qué POKéMON quieres elegir?", 0);
            int option = IO.intToString();
            switch (option){
                case 1:
                    if(pokemonFighter == myPokemons[0])
                    {
                        IO.slowType("Elige otro POKéMON", 0);
                    }
                    else
                    {
                        pokemonFighter = myPokemons[0];
                        return pokemonFighter;
                    }
                    break;
                case 2:
                    if (pokemonFighter == myPokemons[1])
                    {
                        IO.slowType("Elige otro POKéMON", 0);
                    }
                    else
                    {
                        pokemonFighter = myPokemons[1];
                        return pokemonFighter;
                    }
                    break;
                case 3:
                    if (pokemonFighter == myPokemons[2])
                    {
                        IO.slowType("Elige otro POKéMON", 0);
                    }
                    else
                    {
                        pokemonFighter = myPokemons[2];
                        return pokemonFighter;
                    }
                    break;
                case 4:
                    if (pokemonFighter == myPokemons[3])
                    {
                        IO.slowType("Elige otro POKéMON", 0);
                    }
                    else
                    {
                        pokemonFighter = myPokemons[3];
                        return pokemonFighter;
                    }
                    break;
                case 5:
                    if (pokemonFighter == myPokemons[4])
                    {
                        IO.slowType("Elige otro POKéMON", 0);
                    }
                    else
                    {
                        pokemonFighter = myPokemons[4];
                        return pokemonFighter;
                    }
                    break;
                case 6:
                    if (pokemonFighter == myPokemons[5])
                    {
                        IO.slowType("\n Elige otro POKéMON", 0);
                    }
                    else
                    {
                        pokemonFighter = myPokemons[5];
                        return pokemonFighter;
                    }
                    break;
                default:
                    IO.slowType("\n Introduce una opción correcta: ", 0);
                    return changePokemon(pokemonFighter);
                    break;
            }
            return changePokemon(pokemonFighter);
        }

        // Capturar
        public void capture(SpeciesPokemon rivalPokemon)
        {
            bool capture;
            int tries = 0;
            int RCm = ((3 * rivalPokemon.getMaxHP() - 2 * rivalPokemon.getCurrentHP()) * 4096 * rivalPokemon.getRc()) / (3 * rivalPokemon.getMaxHP());
            double ag = 65536 / (Math.Pow((255 / RCm), 0.1875));
            Random r = new Random();
            do
            {
                int num = r.Next(0, 65536);
                if (num >= ag)
                {
                    capture = false;
                    tries = tries + 1;
                    Console.WriteLine("\n ¡QUÉ LÁSTIMA! El POKéMOn rival " + rivalPokemon.getName() + " no ha sido capturado");
                    break;
                }else
                {
                    capture = true;
                    Console.WriteLine("\n ¡ENHORBUENA! El POKéMON rival " + rivalPokemon.getName() + " ha sido capturado.");
                    rivalPokemon.setDate(DateTime.Now);
                    addCapture(rivalPokemon);
                    mainMenu();
                    break;
                }
            } while (tries < 5);
        }

        // Añadir POKéMON capturado a la bolsa
        public void addCapture(SpeciesPokemon rivalPokemon)
        {
            IO.slowType("\n ¿En qué posición desea guardar tu nuevo POKéMON? (Si introduce una lugar ocupado, perderá su POKéMOn anterior): ", 0);
            int pos = IO.intToString();
            for (int i = 0; i < myPokemons.Length; ++i)
            {
                if (myPokemons[i] == null)
                {
                    switch (pos)
                    {
                        case 1:
                            myPokemons[0] = rivalPokemon;
                            break;
                        case 2:
                            myPokemons[1] = rivalPokemon;
                            break;
                        case 3:
                            myPokemons[2] = rivalPokemon;
                            break;
                        case 4:
                            myPokemons[3] = rivalPokemon;
                            break;
                        case 5:
                            myPokemons[4] = rivalPokemon;
                            break;
                        case 6:
                            myPokemons[5] = rivalPokemon;
                            break;

                    }
                }
            }
        }
        
        // Escapar
        public void getAway(SpeciesPokemon miPokemon, SpeciesPokemon rivalPokemon)
        {
            bool getAway;
            int attemps = 0;
            Random random = new Random();
            int num = random.Next(0, 256);
            if (miPokemon.getSpeed() > rivalPokemon.getSpeed())
            {
                getAway = true;
                IO.slowType("\nHas escapado de tu rival.", 0);
                mainMenu();
                rivalPokemon.setCurrentHP(rivalPokemon.getMaxHP());
                attemps = 1;
            }
            else
            {
                int oddScape = (((miPokemon.getSpeed() * 128) / rivalPokemon.getSpeed()) + 30 + attemps) % 256;
                if (num < oddScape)
                {
                    getAway = true;
                    IO.slowType("\nHas escapado de tu rival.", 0);
                    rivalPokemon.setCurrentHP(rivalPokemon.getMaxHP());
                    mainMenu();
                }
                else
                {
                    getAway = false;
                    IO.slowType("\n¡Qué lástima! ¡No has conseguido escapar!", 0);
                    attemps = attemps + 1;
                    damage(rivalPokemon, miPokemon);
                    miPokemon.setCurrentHP(miPokemon.getCurrentHP() - damage(rivalPokemon, miPokemon));
                    IO.slowType("\n Tu pokemon " + miPokemon.getName() + " tiene " + miPokemon.getCurrentHP() + " de vida actual.", 0);
                    IO.slowType("\n Tu pokemon rival " + rivalPokemon.getName() + " tiene " + rivalPokemon.getCurrentHP() + " de vida actual.", 0);
                }
            }
        }

        // Debilitado o no
        public void weakened(SpeciesPokemon myPokemon, SpeciesPokemon rivalPokemon)
        {
            if(myPokemon.getCurrentHP() <= 0 )
            {
                myPokemon.setCurrentHP(0);
                IO.slowType("\n Tu pokemon " + myPokemon.getName() + " tiene " + myPokemon.getCurrentHP() + " de vida actual.", 0);
                IO.slowType("\n Tu pokemon rival " + rivalPokemon.getName() + " tiene " + rivalPokemon.getCurrentHP() + " de vida actual.", 0);
                IO.slowType("\n El pokemon " + myPokemon.getName() + " ha quedado debilitado.", 0);
                IO.slowType("\n ¡Qué lástima! Has perdido el combate.", 0);
                mainMenu();
            }
            if (rivalPokemon.getCurrentHP() <= 0)
            {
                rivalPokemon.setCurrentHP(0);
                IO.slowType("\n Tu pokemon " + myPokemon.getName() + " tiene " + myPokemon.getCurrentHP() + " de vida actual.", 0);
                IO.slowType("\n Tu pokemon rival " + rivalPokemon.getName() + " tiene " + rivalPokemon.getCurrentHP() + " de vida actual.", 0);
                IO.slowType("\n El pokemon " + rivalPokemon.getName() + " ha quedado debilitado.", 0);
                IO.slowType("\n ¡Enhorabuena! Has ganado el combate.", 0);
                mainMenu();
            }
        }

        // Critical
        public double critical()
        {
            Random r = new Random();
            double crit = r.Next(0, 25);
            if (crit == 1)
            {
                return 1.5;
            }
            else
            {
                return 1;
            }
        }

        // Daño
        public int damage(SpeciesPokemon pokemon1, SpeciesPokemon pokemon2)
        {
            Random r = new Random();
            double rand = r.Next(85, 101);
            double daño = (((2 * 50 * (pokemon1.getAtack() / pokemon2.getDefense())) / 50) + 2) * (rand / 100) * critical();
            return (int)daño;
        }
    }
}
