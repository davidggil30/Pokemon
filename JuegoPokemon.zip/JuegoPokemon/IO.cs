﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Remoting.Messaging;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace JuegoPokemon
{
    class IO
    {
        // Escribir lento
        public static void slowType(string s, int wait)
        {
            for (int i = 0; i < s.Length; i++)
            {
                Console.Write(s[i]);
                Thread.Sleep(wait);
            }
        }
        // Introducir número por teclado
        public static int intToString()
        {
            int number = int.Parse(Console.ReadLine());
            return number;
        }
        // Introducir texto por teclado
        public static string text()
        {
            string text = Console.ReadLine();
            return text;
        }
    }
}
